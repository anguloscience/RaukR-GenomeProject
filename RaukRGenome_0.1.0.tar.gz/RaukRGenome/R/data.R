#' A tidyvcfR object
#'
#' A tidyvcfR object that is File downloaded from the IGSR https://www.internationalgenome.org/data FTP site.
#' Originally named ALL.chr22.phase3_shapeit2_mvncall_integrated_v5b.20130502.genotypes.vcf
#' it is a VCF format file with population allele frequencies of variants on chromosome 22.
#' For size purposes the file supplied in RaukR has been filtered to 20000 random variants
#'  across chromosome 22. Data is from 2504 individuals. This file is further filtered to
#'  contain genotype data for only 30000 rows
#'
#'
#' @format A tidyvcfR object with 20000 variants and genotype variants for 30000 rows
#' \describe{
#'   \item{fix}{Fixed variant dataframe}
#'   \item{gt}{Genotype dataframe from individuals.}
#'   \item{meta}{Metadata for the vcf file}
#' }
#' @source \url{https://www.internationalgenome.org/data}
"data_subset"
